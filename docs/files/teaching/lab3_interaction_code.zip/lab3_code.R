source("interaction_code.R")

# Simulate data for lab ---------------------------------------------------

n <- 5000
set.seed(451)
E1 <- rbinom(n, size=1, p=0.2)  # generate a binary genetic exposure
set.seed(1984)
E2 <- rbinom(n, size=1, p=.75)

# binary confounder that is correlated with both exposures
# linear predictor from which to generate C
linpred <- 1 + 1.5*E1 + 2.2*E2
# expit to back-transform logits into probabilities
probs <- exp(linpred) / (1 + exp(linpred))
# generate C
set.seed(451)
C <- rbinom(n, size=1, p=probs)

# true betas for Y
beta0 <- log(1)
betaE1 <- log(1.17)
betaE2 <- log(1.15)
betaE1E2 <- log(1.7)

# for generation of Y
linpred <- beta0 + betaE1*E1 + betaE2*E2 + betaE1E2*E1*E2
probs <- exp(linpred) / (1 + exp(linpred))
set.seed(22)
Y <- rbinom(n, size=1, p=probs)


# Estimating interactions in R --------------------------------------------

# fit logistic model with interaction
m <- glm(Y ~ E1*E2 + C, family=binomial(link="logit"))
summary(m)

# use interaction code to calculate RERI, AP, etc
additive_interactions(m)


