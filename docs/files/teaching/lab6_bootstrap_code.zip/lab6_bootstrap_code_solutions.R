library(boot)
library(ggplot2)
library(sandwich)
library(lmtest)

source("lab6_functions.R")

# Getting comfortable with simulations ------------------------------------

# Monte carlo simulations are powerful tools for understanding estimation
# theory. They allow us to mimic the process of running hundreds or thousands or
# millions of repeated studies on the same population without having to spend
# all the time and effort to collect the data. In this lab, we'll be using
# simulations to understand why we might need the bootstrap and how it works,
# but first we'll use simulations to help us review some basic concepts from
# PHS2000A.

# R has a lot of functions for simulating data, but to reduce the amount of
# coding necessary for this lab we've created a single function that simulates
# the process of drawing random samples (Y,X) from an infinite super-population
# in which Y and X are related by a known model of the form:
#                   Y_i = b0 + b1 * X_i + e_i
# the function takes the following arguments: 
# n  = the number of samples to draw (i.e. the sample size)
# b0 = the intercept for the population model
# b1 = the slope for the population model (i.e. change in mean of Y for 
#      a one-unit change in X)
# error = character vector specifying the error structure, one of
#         normal - errors are drawn from N(0,1)
#         heteroscedastic - variance of errors changes with X
#         beta - errors are non-normal (drawn from bimodal beta distribution)
#         clustered - errors are clustered within variable C (must also specify number of clusters m)
# m = optional number of clusters when using clustered errors option

# Run the code below to draw a single sample of size 100 from a population in
# which b0 = 0.1 and b1 = 0.2. Inspect the data.frame it creates to get a feel for
# the data.
df <- sample_from_population_model(n = 100, b0 = 0.1, b1 = 0.2)
df

# Run a simple linear regression of Y vs. X using the sample data. 
# interpret the point estimate and standard error for b1.

fit <- lm(Y ~ X, data = df)
summary(fit)

# What is a sampling distribution? ----------------------------------------

# We can use our simulation function in R to simulate that which we normally
# couldn't see: the sampling distribution! Write a loop to simulate drawing
# 1000 samples of size 100 from the population collect the b1 estimates
# and calculate the standard error. How does this compare to the asymptotic SE
# calculated above?

b_sim <- vector()
for (i in 1:1000) {
  # sample from population
  df <- sample_from_population_model(n = 100, b0 = 0.1, b1 = 0.2)
  
  # run model
  fit <- lm(Y ~ X, data = df)
  
  # collect b1 terms
  b_sim[i] <- coef(fit)[2]
}

sd(b_sim)

# When classic standard errors fail ---------------------------------------

# Often times the normality assumption about the distribution of the
# error term is unjustified. What happens when we use a different distribution?
# The code below now samples from a population in which errors have 
# a beta distribution (bi-modal more likely extreme values)

df <- sample_from_population_model(n = 20, b0 = 0.1, b1 = 0.2, errors = "beta")

# Run a simple linear regression of Y vs. X using the sample data. 
# interpret the point estimate and standard error for b1. Plot the residuals 
# do they look normal? (Hint: use resid() function to extract residuals and
# hist() to get a histogram, alternatively run plot() on model object)

fit <- lm(Y ~ X, data = df)
summary(fit)

plot(fit)

hist(resid(fit))

# Simulate the sampling distribution for b1 and compare the "true" standard
# error to the result from a single sample. What do you find? What happens
# if you increase the size of samples?

b_sim <- vector()
for (i in 1:1000) {
  # sample from population
  df <- sample_from_population_model(n = 20, b0 = 0.1, b1 = 0.2, errors = "beta")
  
  # run model
  fit <- lm(Y ~ X, data = df)
  
  # collect b1 terms
  b_sim[i] <- coef(fit)[2]
}

sd(b_sim)

# Using the bootstrap -----------------------------------------------------

B <- 1000 # number of bootstrap replicates
n <- 20   # sample size 
b0 <- 0.1 # beta_0 in population model
b1 <- 0.2 # beta_1 in population model

df <- sample_from_population_model(n, b0, b1, errors = "beta")

fit <- lm(Y ~ X, data = df)
summary(fit)

# Option 1: for loop ------------------------------------------------------

# The first option for coding the bootstrap is to use a simple for loop. The
# following code loops over B bootstrap replications. In each iteration it draws
# an random sample with replacement from the observed data, estimates our
# regression of interest, and collects estimate of beta_1.

# intialize a vector
beta_b <- vector()

# perform B bootstrap iterations 
for (i in 1:B) {
  # sample with replacement from observed data 
  df_b <- df[sample(1:n, n, replace = TRUE), ] 
  
  # run regression on bootstraped sample
  fit_b <- lm(Y ~ X, data = df_b)
  
  # extract coefficient
  beta_b[i] <- coef(fit_b)[2]
}

# calculate a bootstrap standard error
sd(beta_b)

# calculate 95% confidence interval using percentile method
quantile(beta_b, c(0.025, 0.975))


# Option 2: replicate -----------------------------------------------------

# Another option is to use the -replicate- function, which takes as a first
# arguments the number of replications to perform, and as a second argument a
# function or block of code to perform in each replication.

beta_b <- replicate(B, {
  df_b <- df[sample(1:n, n, replace = TRUE), ] 
  fit_b <- lm(Y ~ X, data = df_b)
  return(coef(fit_b)[2])
})

# calculate a bootstrap standard error
sd(beta_b)

# calculate 95% confidence interval using percentile method
quantile(beta_b, c(0.025, 0.975))


# Option 3: boot package --------------------------------------------------

# Another option is to use the -boot- package. The set up is similar to using
# replicate, however the first argument is now the data, the second is a
# function to apply to boostrap samples to calculate statistic of interest, and
# third is the number of replicates. The advantage of the boot package is that
# it is parallelized so can run much faster on computers with multiple processors

boot_func <- function(data, ind) {
  fit <- lm(Y ~ X, data = data[ind, ])
  beta <- coef(fit)[2]
  return(beta)
}

beta_b <- boot(df, boot_func, B) # note that beta_b is now a boot object not just a vector of betas

# calculate a bootstrap standard error
sd(beta_b$t)

# calculate 95% confidence interval using percentile method
quantile(beta_b$t, c(0.025, 0.975))


# The bootstrap-t ---------------------------------------------------------

# Practice your bootstrap skills by coding up the bootstrap-t variant of
# the boostrap for the same sample data above. Use 1000 bootstrap replications
# to calculate a p-value. Interpret your findings

t_b <- replicate(B, {
  df_b <- df[sample(1:n, n, replace = TRUE),]
  
  fit_b <- lm(Y ~ X, data = df_b)
  
  return(coef(summary(fit_b))[2, 3])
})

# calculate p-value 
mean(abs(t_b) >= abs(coef(summary(fit))[2, 3]))

# The cluster bootstrap ---------------------------------------------------

n <- 100
df <- sample_from_population_model(n, b0, b1, errors = "clustered", m = 10)

# Practice your bootstrap skills by coding up a "cluster/block" bootstrap 
# for the sample of clustered data above. Use 1000 bootstrap replications
# to calculate the SE and 95% CI accounting for clustering.

# Note: now the sample from the population model creates variables (Y, X, C)
# where C is an indicator of the cluster. Within clusters errors are correlated.

# get unique list of clusters in data to sample from
clus <- unique(df$C)

beta_b <- replicate(B, {
  # sample clusters with replacement instead of individual observations
  clus_b <- sample(clus, length(clus), replace = TRUE)
  
  # assemble the data from the sampled clusters into the bootstrapped dataset
  ind_b <- sapply(clus_b, function(x) which(df[, "C"]==x))
  df_b <- df[ind_b, ]
  
  # fit the model on the bootstrap dataset in the normal way and extract coef
  fit_b <- lm(Y ~ X, data = df_b)
  
  return(coef(fit_b)[2])
})

# calculate 95% confidence interval using percentile method
quantile(beta_b, c(0.025, 0.975))

# a simpler alternative from the sandwich package is 
fit <- lm(Y ~ X, data = df) # fit the model on observed data
vcov <- vcovBS(fit, cluster = ~ C, R = B) # vcov runs cluster bootstrap in background

coefci(fit, vcov = vcov) # get adjusted CIs (note these are based on Normal Approximation)

# The residual bootstrap --------------------------------------------------

n <- 100
df <- sample_from_population_model(n, b0, b1, errors = "beta")

# Practice your bootstrap skills by coding up a "residal" bootstrap 
# for the sample with beta-distributed errors above. Use 1000 bootstrap 
# replications to calculate the SE and 95% CI accounting for clustering.

# first fit the model on the observed data and extract residuals and predictions
fit <- lm(Y ~ X, data = df)
df$resid <- resid(fit)
df$Y_hat <- predict(fit)

beta_b <- replicate(B, {
  # sample residuals with replacement 
  e_b <- df$resid[sample(1:n, n, replace = TRUE)] 
  
  # create adjusted outcome
  df$Y_star <- df$Y_hat + e_b
  
  # fit model on adjusted outcome and extract coefficient
  fit_b <- lm(Y_star ~ X, data = df)
  return(coef(fit_b)[2])
})

# calculate 95% confidence interval using percentile method
quantile(beta_b, c(0.025, 0.975))

# again a simpler alternative from the sandwich package is 
fit <- lm(Y ~ X, data = df) # fit the model on observed data
vcov <- vcovBS(fit, type = "residual", R = B) # vcovBS runs residual bootstrap in background

coefci(fit, vcov = vcov) # get adjusted CIs (note these are based on Normal Approximation)

# More complicated estimator ----------------------------------------------

# Often in practice we will use the bootstrap when we want to get uncertainty
# estimates for more complex statistics (e.g. the output from the g-formula). 
# In this example you'll use the bootstrap to get a confidence interval for
# the marginal risk difference from a logistic regression model 

# this new function generates a sample from the following population model
#          logit Y = b0 + b1 X1 + b2 X2
# where X1 is our covariate of interest (a treatment) and X2 is 
# a potential confounder (age)
df <- sample_from_risk_difference_model(100, -13, -0.2, 0.25)


# using your previous R knowledge we can estimate a logistic regression model
# on our sample using 

fit <- glm(Y ~ X1 + X2, data = df, family = binomial(link = "logit"))

# we can calculate an estimate of the marginal risk difference using the following code
rd <- 0

for (age in 40:60) { # we'll go through every age
  
  # find the proportion of the sample at that age
  p_age <- mean(df$X2 == age) 
  
  # calculate the age-specific risk difference
  rd_age <- expit(coef(fit)[1] + coef(fit)[2] + coef(fit)[3]*age) - 
    expit(coef(fit)[1] + coef(fit)[3]*age) 
  
  rd <- rd + rd_age * p_age # multiply the two, summing as we go along
}
rd

# so this is our estimate based on our sample but we need a confidence interval!
# enter the bootstrap! using the code above calculate a bootstrap-based confidence
# interval for the marginal risk difference.

rd_b <- replicate(B, {
  df_b <- df[sample(1:n, n, replace = TRUE), ] 
  fit_b <- glm(Y ~ X1 + X2, data = df_b, family = binomial(link = "logit"))
  rd_b <- 0
  
  for (age in 40:60) { # we'll go through every age
    
    # find the proportion of the sample at that age
    p_age <- mean(df_b$X2 == age) 
    
    # calculate the age-specific risk difference
    rd_age <- expit(coef(fit)[1] + coef(fit)[2] + coef(fit)[3]*age) - 
      expit(coef(fit)[1] + coef(fit)[3]*age) 
    
    rd_b <- rd_b + rd_age * p_age # multiply the two, summing as we go along
  }
  
  return(rd_b)
})

# calculate 95% confidence interval using percentile method
quantile(rd_b, c(0.025, 0.975))
