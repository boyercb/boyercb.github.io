sample_from_population_model <- function(n, b0, b1, errors = "normal", m = NULL) {
  
  e <- switch(
    errors,
    "normal" = rnorm(n),
    "beta" = 4 * (rbeta(n, 0.5, 0.5) - 0.5),
    "heteroscedastic" = rnorm(n, sd = sqrt((1:n)^1.4)),
    "clustered" = rnorm(n, 0, sqrt(0.5)) + rep(rnorm(m, 0, sqrt(0.5)), each = n / m)
  )
  
  X <- runif(n, 0, 10)
  Y <- b0 + b1 * X + e
  
  df <- data.frame(
    X = X,
    Y = Y
  )
  
  if (errors == "clustered") {
    df$C <- rep(1:m, each = n / m)
  }
  
  return(df)
} 

expit <- function(x) {
  exp(x) / (1 + exp(x))
}

sample_from_risk_difference_model <- function(n, b0, b1, b2) {
  
  X1 <- rbinom(n, 1, .5)
  X2 <- round(runif(n, 40, 60))
  
  p <- expit(b0 + b1*X1 + b2*X2)
  Y <- rbinom(n, 1, p)
  
  df <- data.frame(
    X1 = X1,
    X2 = X2,
    Y = Y
  )
  
  return(df)
}
