# Read in necessary libraries
library("mediation")
library("sas7bdat")
library("foreign")
library("knitr")

p = read.spss("pilotpenguins.sav", to.data.frame=TRUE)

# do complete-cases analysis
# this is almost never a good idea
# we will discuss in missing data lecture
p = p[ complete.cases(p), ]

p$social2 = p$socialdiversity > median(p$socialdiversity, na.rm=TRUE)  # median split
p$anx2 = p$anxiety > median(p$anxiety, na.rm=TRUE)  # median split
p$stress2 = p$stress > median(p$stress, na.rm=TRUE)  # median split

summary( glm(anx2 ~ social2, data=p, family=binomial(link="logit")) )

# fit mediator regression
b = glm(stress2 ~ social2, data=p, family=binomial(link="logit"))

# fit outcome regression
c = glm(anx2 ~ stress2 * social2, data=p, family=binomial(link="logit"))  

mediate(b, c, boot=TRUE, sims=500, treat="social2", mediator="stress2") # THIS SHOULD FAIL

# fit mediator regression
b = glm(stress2 ~ social2, data=p, family=binomial(link="logit"))  # mediator regression

# fit outcome regression
c = glm(anx2 ~ stress2 * social2, data=p, family=binomial(link="logit"))  # outcome regression

set.seed(1234)
med = mediate(b, c, boot=FALSE, sims=500, treat="social2", mediator="stress2")
summary(med)

# sanity check: total effect decomposition
print( paste( "ACME (treated) + ADE (control) = ", med$d1 + med$z0, sep="" ) )
print( paste( "TE = ", med$tau.coef, sep="" ) )

# sanity check: proportion mediated
print( paste( "ACME (treated) / TE = ", med$d1 / (med$d1 + med$z0), sep="" ) )
print( paste( "Proportion mediated (treated) = ", med$n1, sep="" ) )