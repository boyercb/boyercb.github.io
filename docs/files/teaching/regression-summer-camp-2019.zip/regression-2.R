## This document takes you through some of the R code we covered in the slides with
## additional exercises for you to complete on your own.
## Exercises are prefaced with a single # so make sure to fill in the document
## with your answers!

## let's start by assuming we're omniscient and know the true function that
## describes the relationship between two random variables. I'll call those
## variables X and Y but you can make them what ever you'd like

X <- runif(10000, 0, 12)        # X is a random number between 0 and 12
Y <- 2 * X + rnorm(10000, 0, 5) # Y is a function of X with some noise

## in this case the conditional expectation function is defined to be
## E[Y | X = x] = 2 * x

## let's bind these together and create a data.frame
df <- cbind(X, Y)
df <- as.data.frame(df)

# In this case is a linear model a good assumption?
# BONUS: if you can try to plot the CEF to see
# Answer:

## Recall that regression is just a recipe for estimating the parameters 
## of our statistical model. let's use the lm() function to estimate
## the parameters using ordinary least squares.
lm(Y ~ X, data = df)

## In real life we're often stuck with samples, so let's take a sample
## the following code just takes the first 100 values
df_sample <- df[1:100, ]

# run another regression on the sample
# how does the estimate you get differ from the one above and why?
# Answer:


# BONUS: change the CEF to be nonlinear and re-run the regression assuming
# a simple linear model. What do you observe?
