## This document takes you through some of the R code we covered in the slides with
## additional exercises for you to complete on your own.
## Exercises are prefaced with a single # so make sure to fill in the document
## with your answers!

# creating random variables -----------------------------------------------

## R let's you generate your own random variables from common distribution
## functions like the normal, binomial, poisson, and uniform distributions
## we discussed in class.

## For example, the following code generates 3 realizations/random samples 
## from a normal distribution with mean 45 and standard deviation 19

rnorm(3, 45, 19)

# Generate a vector of 100 realizations from your favorite distribution
# and save the results to 
# Answer:

# BONUS: plot your 100 realizations in a histogram
# Answer:

# covariance, correlation, and independence -------------------------------

## In R we can calculate the correlation and covariance using the cor()
## and cov() functions. For example

x <- rnorm(1000, 10, 2)
y <- rnorm(1000, 8, 3)

cor(x, y)
cov(x, y)

# Aside what do you get when you run these? Why might that be?
# Answer:

# What happens if you define y as a function of x, i.e.
y <- 10 * x
# What is the covariance and correlation now and why?
# Answer:

## To generate two random variables with known covariance and/or 
## correlation we can also simulate a joint distribution, in
## this case the multivariate normal, using a function from
## the MASS package. 

## if you don't have it installed you will have to run
install.packages(MASS)

## then to load MASS we can run
library(MASS)


# Use the mvrnorm() function to generate 100 samples/realizations from
# the multivariate normal with means 10 and 15, and covariance 40
# Answer:

# Now verify the covariance and calculate the correlation (BONUS: calculate
# the correlation from the covariance and standard deviations -- use sd() for
# the latter)
# Answer:

# Final BONUS! graph the relationship between X and Y

